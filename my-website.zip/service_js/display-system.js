document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("summary-name").innerText = sessionStorage.getItem("name") || "N/A";
  document.getElementById("summary-business").innerText = sessionStorage.getItem("business") || "";
  document.getElementById("summary-email").innerText = sessionStorage.getItem("email") || "N/A";
  document.getElementById("summary-phone").innerText = sessionStorage.getItem("phone") || "N/A";
  document.getElementById("summary-dropoff").innerText = sessionStorage.getItem("drop off address") || "N/A";
  document.getElementById("summary-address").textContent =
    sessionStorage.getItem("address") || "";

  document.getElementById("summary-service").innerText = sessionStorage.getItem("service") || "N/A";
  document.getElementById("summary-description").innerText = sessionStorage.getItem("description") || "None";
});

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('payment-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const terms = document.getElementById('disclaimer');
    if (!terms || !terms.checked) {
      alert('Please read the Terms and check the box before continuing.');
      return;
    }

    // (Optional) saveFields() if you still need it here
    try { if (typeof window.saveFields === 'function') window.saveFields(); } catch {}

    // 🔥 wipe the session for this tab, then go to Thanks
    sessionStorage.clear();
    window.location.assign('/service_pages/Thanks.html');
  });
});
