(() => {
  ['name','email','phone','business','address','drop off address','dropoff-address','service','description','photosList']
    .forEach(k => sessionStorage.removeItem(k));
})();

function saveFields() {
  // ✅ CLEAR ONLY the keys we use, right before saving
  ['name','email','phone','business','address','drop off address','dropoff-address','service','description','photosList','__source']
    .forEach(k => sessionStorage.removeItem(k));

  // ✅ STAMP where this data came from (the current page)
  sessionStorage.setItem('__source', location.pathname);

  const standard = ["full-name", "phone-number", "email", "business-name"];
  const extra = [];

  // ... KEEP everything else in your saveFields() exactly as you have it ...
  // (no other changes needed below)
}

function saveFields() {
  const standard = ["full-name", "phone-number", "email", "business-name"];
  const extra = [];

  // Get the address from Mapbox input if it exists
  let address = "";
  const mapboxInput = document.querySelector('.mapboxgl-ctrl-geocoder input[type="text"]');
  if (mapboxInput) {
    address = mapboxInput.value.trim();
  } else {
    // fallback if geocoder input wasn't found
    address = document.getElementById("address-search")?.value || "";
  }

  // Save to sessionStorage
  sessionStorage.setItem("name", document.getElementById("full-name")?.value || "");
  sessionStorage.setItem("phone", document.getElementById("phone-number")?.value || "");
  sessionStorage.setItem("email", document.getElementById("email")?.value || "");
  sessionStorage.setItem("address", address);
  sessionStorage.setItem("drop off address", document.getElementById("dropoff-address")?.value || "");
  sessionStorage.setItem("business",
  document.getElementById("business-name")?.value ||
  document.querySelector('[name="business-name"]')?.value ||
  document.querySelector('[name="business"]')?.value ||
  ""
);

  // Save only relevant custom questions
  document.querySelectorAll("input, textarea, select").forEach((el) => {
    const id = el.id?.trim();
    const name = el.name?.trim();
    const isStandard = standard.includes(id);
    const isPackage = name === "package" || (id && id.toLowerCase().includes("package"));
    const isAddress = el.closest(".mapboxgl-ctrl-geocoder") !== null;

    if (!isStandard && !isPackage && !isAddress && el.value.trim() !== "") {
      const label = document.querySelector(`label[for="${el.id}"]`);
      const labelText = label?.innerText || el.name || el.id;
      extra.push(`${labelText}: ${el.value}`);
    }
  });

  sessionStorage.setItem("description", extra.join(" | "));

  // Save total price from service page (includes mileage + package)
  const totalText = document.getElementById("total-price")?.textContent || "";
  const totalAmount = totalText.replace(/[^\d.]/g, ""); // Remove non-numeric text
  sessionStorage.setItem("finalTotal", totalAmount);
}

// prefer #service, fallback to #service-type, fallback to <title>
const svcEl = document.getElementById('service') || document.getElementById('service-type');
sessionStorage.setItem('service', (svcEl ? svcEl.value : document.title).trim());

window.saveFields = saveFields;

// This script ensures the service name is always saved consistently.
// Prefer #service, fallback to #service-type, fallback to <title>
(function(){
  document.addEventListener('DOMContentLoaded', () => {
    const svc = document.getElementById('service')?.value
             || document.getElementById('service-type')?.value
             || document.title;

    const clean = (svc || '').trim();
    sessionStorage.setItem('service', clean);
    console.log('FORCED service →', sessionStorage.getItem('service'));
  });
})();

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('booking-form') || document.querySelector('form');
  if (!form) return;

  // sessionStorage only persists in same tab
  form.removeAttribute('target');

  form.addEventListener('submit', () => {
    try { saveFields(); } catch (e) { console.error('saveFields error:', e); }
  });
});

