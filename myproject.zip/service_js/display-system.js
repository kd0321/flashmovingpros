document.addEventListener('DOMContentLoaded', () => {
  document.getElementById("summary-name").innerText = localStorage.getItem("name") || "N/A";
  document.getElementById("summary-business").innerText = localStorage.getItem("business") || "";
  document.getElementById("summary-email").innerText = localStorage.getItem("email") || "N/A";
  document.getElementById("summary-phone").innerText = localStorage.getItem("phone") || "N/A";
  document.getElementById("summary-address").textContent =
  localStorage.getItem("address") || "";

  document.getElementById("summary-service").innerText = localStorage.getItem("service") || "N/A";
  document.getElementById("summary-description").innerText = localStorage.getItem("description") || "None";
  document.getElementById("summary-total").textContent =
  localStorage.getItem("finalTotal")
    ? `$${localStorage.getItem("finalTotal")}`
    : "$0.00";

});
