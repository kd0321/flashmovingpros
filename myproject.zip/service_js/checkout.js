// /js/checkout.js
(function () {
  function q(name) {
    try { return (new URL(location.href)).searchParams.get(name) || ''; }
    catch (_) { return ''; }
  }
  function money(n){ return '$' + (Math.round(n * 100) / 100).toFixed(2); }

  // inputs
  let service = (q('service') || localStorage.getItem('service') || 'residential').toLowerCase();
  let crewRaw = (q('crew') || localStorage.getItem('crew-size') || '1-2').toLowerCase();
  // normalize crew (robust to weird values)
  let crew = (crewRaw === '3' || crewRaw.includes('3')) ? '3' : '1-2';

  const isSpecialty = (service === 'speciality') || /special/i.test(service);

  const rates = isSpecialty
    ? { '1-2': 200, '3': 300 }
    : { '1-2': 150, '3': 225 };

  const rate = rates[crew];
  const deposit = rate * 2.5;
  const depositCents = Math.round(deposit * 100);

  // ---- Write into your EXISTING total fields ----
  // We’ll try common total fields automatically (first one found wins).
  const totalTargets = [
    '#total', '#order-total', '#grand-total', '#amount-due', '#checkout-total',
    '[data-total]', 'input[name="total"]', 'input[name="amount"]'
  ];

  function setTotalDisplay(amountText) {
    for (const sel of totalTargets) {
      const el = document.querySelector(sel);
      if (!el) continue;
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.value = amountText.replace(/^\$/, ''); // plain number if input expects it
      } else {
        el.textContent = amountText; // visual display node
      }
      return true;
    }
    return false;
  }

  // Replace the visible TOTAL with the 2.5h deposit amount
  setTotalDisplay(money(deposit));

  // Hidden fields (optional — only if present or we can create them)
  function ensureHidden(id, name, val) {
    let el = document.getElementById(id);
    if (!el) {
      const form = document.forms[0];
      if (!form) return; // no form to attach to; skip quietly
      el = document.createElement('input');
      el.type = 'hidden';
      el.id = id;
      el.name = name;
      form.appendChild(el);
    }
    el.value = String(val);
  }

  // Common hidden fields some setups use
  // (if your form already has differently named fields, tell me the names and I’ll map to them)
  ensureHidden('deposit_cents', 'deposit_cents', depositCents);
  ensureHidden('total_cents', 'total_cents', depositCents); // total == deposit per your spec

  // Optional: expose for debugging
  window.__checkout = { service, crew, rate, deposit, depositCents };
})();
