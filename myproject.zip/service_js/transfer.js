// /js/booking-shared.js
(function () {
  function detectService() {
    // detect by filename: residential.html, commercial.html, loading.html, packing.html, appliance.html, speciality.html
    try {
      const m = location.pathname.toLowerCase().match(/(residential|commercial|loading|packing|appliance|speciality)\.html/);
      if (m) return m[1];
    } catch (_) {}
    // optional fallback: meta[name=service]
    const meta = document.querySelector('meta[name="service"]');
    if (meta && meta.content) return meta.content.toLowerCase();
    return 'residential';
  }

  function normalizeCrew(sel) {
    // robust: accept values like "3", "3 movers", or text that contains "3"
    if (!sel) return '1-2';
    const opt = sel.options[sel.selectedIndex] || null;
    const val = (sel.value || '').trim().toLowerCase();
    if (val === '3' || val === '3 movers' || val === '3-movers') return '3';
    const txt = (opt && (opt.text || opt.label) || '').toLowerCase();
    if (txt.includes('3')) return '3';
    return '1-2';
  }

  function goToCheckout(service, crew) {
    try {
      localStorage.setItem('service', service);
      localStorage.setItem('crew-size', crew);
    } catch (_) {}
    location.href = `/checkout.html?service=${encodeURIComponent(service)}&crew=${encodeURIComponent(crew)}`;
  }

  function init() {
    const btn = document.getElementById('book-services-button');
    if (!btn) return;
    btn.addEventListener('click', function () {
      const sel = document.getElementById('crew-size');
      const crew = normalizeCrew(sel);
      const service = detectService();
      goToCheckout(service, crew);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // optional export
  window.__bookingShared = { detectService, normalizeCrew, goToCheckout };
})();
